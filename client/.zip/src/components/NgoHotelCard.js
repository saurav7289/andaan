import React from 'react';

const NgoHotelCard = (props) => {
  return (
    <>
      <div className="row m-1 p-1 mb-5 m-auto" style={{ height: '150px' }}>
        <div className="card" style={{ width: 'auto' }} key={props.detail._id}>
          <div className="card-body">
            <h5 className="card-title">
              <span style={{ fontSize: '15px', marginRight: '5px' }}>NGO:</span>{' '}
              <b>{props.detail.ngoName}</b>
            </h5>
            <h4 className="card-title">
              <span style={{ fontSize: '15px', marginRight: '5px' }}>
                Restaurant:
              </span>{' '}
              <b>{props.detail.restruantName}</b>
            </h4>
            <span style={{ float: 'right' }}>🤝</span>
          </div>
          <ul className="list-group list-group-flush">
            <li className="list-group-item">
              {props.detail.foodType}{' '}
              <span className="ms-5">Qty: {props.detail.foodQty} kg</span>
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default NgoHotelCard;
